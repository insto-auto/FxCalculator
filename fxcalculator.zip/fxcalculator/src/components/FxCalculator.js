import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/FxCalculator.css';

class FxCalculator extends React.Component{
    constructor(props){
        super(props);
        this.state = {converetedFxValue:""};
        this.inputFxRef = React.createRef()
        this.covertingFxRef = React.createRef()
    }
    fxCalculatorClear = (e) => {
        e.preventDefault();
        this.inputFxRef.current.value = "";
        this.covertingFxRef.current.value = "";
        this.setState({converetedFxValue:""});
    }
FxCalculator = (e) => {
    e.preventDefault();
    if (this.inputFxRef.current.value !== "" && this.covertingFxRef.current.value) {
        var USD = {
            "AUD": 0.8371,
            "CAD": 0.8711,
            "CNY": 0.1620,
            "EUR": 1.2315,
            "GBP": 1.5683,
            "NZD": 0.7750,
            "JPY": 0.0083,
            "CZK": 0.0446,
            "DKK": 0.1655,
            "NOK": 0.1421
        };
        var convertedValue;
        var inputValueForConverting = this.inputFxRef.current.value.split(" ");
        var inputValueForConvertingToUnit = this.covertingFxRef.current.value.toUpperCase();
        var inputValueForConvertingUnit = inputValueForConverting[0].toUpperCase();
        var inputValueForConvertingNumber = parseFloat(inputValueForConverting[1]);
    
    
        if (inputValueForConvertingUnit === inputValueForConvertingToUnit) {
            convertedValue = inputValueForConvertingNumber;
            convertedValue = convertedValue.toFixed(2);
            convertedValue = "Converted Value: " + inputValueForConvertingToUnit + " " + convertedValue;
            this.setState({
                converetedFxValue: convertedValue
            });
        } else if (inputValueForConvertingUnit === "USD" || inputValueForConvertingToUnit === "USD") {
            if (inputValueForConvertingUnit === "USD") {
                convertedValue = inputValueForConvertingNumber / USD[inputValueForConvertingToUnit];
                convertedValue = convertedValue.toFixed(2);
            convertedValue = "Converted Value: " + inputValueForConvertingToUnit + " " + convertedValue;
            this.setState({
                converetedFxValue: convertedValue
            });
            } else {
                convertedValue = inputValueForConvertingNumber * USD[inputValueForConvertingUnit];
                convertedValue = convertedValue.toFixed(2);
            convertedValue = "Converted Value: " + inputValueForConvertingToUnit + " " + convertedValue;
            this.setState({
                converetedFxValue: convertedValue
            });
            }
    
        } else if (typeof(USD[inputValueForConvertingUnit]) === "undefined" || typeof(USD[inputValueForConvertingToUnit]) === "undefined") {
            alert("Unable to find rate for " + inputValueForConvertingUnit + "/" + inputValueForConvertingToUnit);
        } else if (inputValueForConvertingUnit !== inputValueForConvertingToUnit) {
            var usdvalueofconvertingnumber = inputValueForConvertingNumber * USD[inputValueForConvertingUnit];
            convertedValue = usdvalueofconvertingnumber / USD[inputValueForConvertingToUnit];
        }
        if (inputValueForConvertingToUnit === "JPY") {
            convertedValue = parseInt(convertedValue);
            convertedValue = "Converted Value: " + inputValueForConvertingToUnit + " " + convertedValue;
            this.setState({
                converetedFxValue: convertedValue
            });
        } else if (typeof(USD[inputValueForConvertingUnit]) !== "undefined" && typeof(USD[inputValueForConvertingToUnit]) !== "undefined" && inputValueForConvertingUnit !== inputValueForConvertingToUnit) {
            convertedValue = convertedValue.toFixed(2);
            convertedValue = "Converted Value: " + inputValueForConvertingToUnit + " " + convertedValue;
            this.setState({
                converetedFxValue: convertedValue
            });
        }
    
    }


}
    render(){
        return(
            <React.Fragment>
            <form>
               <div className="Fx-Calculator col-12">
                  <div className="form-group">
                     <label>From :</label>
                     <input type="text" className="form-control 
                        Fx-Calculator-Converting-Input-Value" placeholder = "AUD 100" ref={this.inputFxRef}/>
                  </div>
                  <div className="form-group Converting-Unit-Container">
                     <label>To :</label>
                     <input type="text" className="form-control
                        Fx-Calculator-Converting-Input-Value-To" placeholder = "AUD" ref={this.covertingFxRef}/>
                  </div>
                  <p className="Converted-Value-Result">{this.state.converetedFxValue}</p>
                  <div className ="Buttons-Container">
                     <button className="Fx-Calculator-Submit-Button" onClick ={(e) => this.FxCalculator(e)}>Submit</button>
                     <button className="Fx-Calculator-Clear-Button"  onClick ={(e) => this.fxCalculatorClear(e)}>Clear</button>
                  </div>
               </div>
            </form>
         </React.Fragment>
        )
    
    }
        
}

export default FxCalculator;