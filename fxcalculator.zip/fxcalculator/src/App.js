import React from 'react';
import './App.css';
import FxCalculator from './components/FxCalculator'
function App() {
  return (
    <div className="App">
     <FxCalculator/>
       
    </div>
  );
}

export default App;
